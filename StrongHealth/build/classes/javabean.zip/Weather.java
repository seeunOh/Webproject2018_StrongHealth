package javabean;

public class Weather {
	private String cityName;
	private String dWeather;
	private String tWeahter;
	private String pop;
	private String humidity;
	private String dust;
	private String sensory;
	private String flu;
	private String eyeDisease;
	private String asthma;
	private String skinDisease;
	private String foodPoison;
	private String frozen;
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getdWeather() {
		return dWeather;
	}
	public void setdWeather(String dWeather) {
		this.dWeather = dWeather;
	}
	public String gettWeahter() {
		return tWeahter;
	}
	public void settWeahter(String tWeahter) {
		this.tWeahter = tWeahter;
	}
	public String getPop() {
		return pop;
	}
	public void setPop(String pop) {
		this.pop = pop;
	}
	public String getHumidity() {
		return humidity;
	}
	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}
	public String getDust() {
		return dust;
	}
	public void setDust(String dust) {
		this.dust = dust;
	}
	public String getSensory() {
		return sensory;
	}
	public void setSensory(String sensory) {
		this.sensory = sensory;
	}
	public String getFlu() {
		return flu;
	}
	public void setFlu(String flu) {
		this.flu = flu;
	}
	public String getEyeDisease() {
		return eyeDisease;
	}
	public void setEyeDisease(String eyeDisease) {
		this.eyeDisease = eyeDisease;
	}
	public String getAsthma() {
		return asthma;
	}
	public void setAsthma(String asthma) {
		this.asthma = asthma;
	}
	public String getSkinDisease() {
		return skinDisease;
	}
	public void setSkinDisease(String skinDisease) {
		this.skinDisease = skinDisease;
	}
	public String getFoodPoison() {
		return foodPoison;
	}
	public void setFoodPoison(String foodPoison) {
		this.foodPoison = foodPoison;
	}
	public String getFrozen() {
		return frozen;
	}
	public void setFrozen(String frozen) {
		this.frozen = frozen;
	}
	
}
